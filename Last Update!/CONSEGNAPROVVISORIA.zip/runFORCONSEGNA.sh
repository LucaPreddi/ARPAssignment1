#!/bin/bash

cd sources
cd executables
./master