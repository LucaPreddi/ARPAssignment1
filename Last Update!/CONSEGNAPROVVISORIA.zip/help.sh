more -d info.txt
more -d ./sources/dmaster/master.txt
more -d ./sources/dcommand/command.txt
more -d ./sources/dinspection/inspection.txt
more -d ./sources/dmotor_x/motor_x.txt
more -d ./sources/dmotor_z/motor_z.txt
more -d ./sources/dwatchdog/watchdog.txt
